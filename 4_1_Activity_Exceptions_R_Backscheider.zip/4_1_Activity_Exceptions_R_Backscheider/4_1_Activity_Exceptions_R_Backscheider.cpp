#include <iostream>
#include <stdexcept>

// Custom exception derived from std::exception
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom Exception: An error occurred.";
    }
};

bool do_even_more_custom_application_logic()
{
    // Issue: Code after the throw statement.
    // Correction: Moved the code after the throw statement to before it.
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    throw std::runtime_error("An error occurred in do_even_more_custom_application_logic");
    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        // Issue: Not catching exceptions from do_even_more_custom_application_logic.
        // Correction: Added a try-catch block to catch exceptions thrown by do_even_more_custom_application_logic.
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Running Custom Application Logic." << std::endl;
        }
    }
    // Catch std::exception
    catch (const std::exception& e)
    {
        std::cerr << "std::exception caught. " << e.what() << std::endl;
    }
    // Catch custom exception
    catch (const CustomException& e)
    {
        std::cerr << "CustomException caught: " << e.what() << std::endl;
    }

    // Issue: Throwing CustomException without catching it.
    // Correction: Added a try-catch block in main to catch the CustomException thrown by do_custom_application_logic.
    std::cout << "Leaving Custom Application Logic." << std::endl;
    throw CustomException(); // Throwing a custom exception derived from std::exception
}

float divide(float num, float den)
{
    // Issue: Limited information in the exception message.
    // Correction: Improved the error message to indicate that the exception is due to division by zero.
    if (den == 0)
    {
        throw std::invalid_argument("Division by zero is not allowed.");
    }
    return (num / den);
}

void do_division() noexcept
{
    try
    {
        float numerator = 10.0f;
        float denominator = 0;

        // Issue: Not catching the specific exception thrown by divide.
        // Correction: Added a try-catch block to catch only the std::invalid_argument exception thrown by divide.
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e)
    {
        std::cerr << "Exception caught in do_division: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }
    // Catch custom exception
    catch (const CustomException& e)
    {
        std::cerr << "CustomException caught in main: " << e.what() << std::endl;
    }
    // Catch std:: exception
    catch (const std::exception& e)
    {
        std::cerr << "std::exception caught in main: " << e.what() << std::endl;
    }
    // Catch any unhandled exceptions
    catch (...)
    {
        std::cerr << "An unexpected exception occurred in main. " << std::endl;
    }

    return 0;
}
